/*
    Copyright (c) 2015, Christopher Nitta
    All rights reserved.

    All source material (source code, images, sounds, etc.) have been provided to
    University of California, Davis students of course ECS 160 for educational
    purposes. It may not be distributed beyond those enrolled in the course without
    prior permission from the copyright holder.

    All sound files, sound fonts, midi files, and images that have been included
    that were extracted from original Warcraft II by Blizzard Entertainment
    were found freely available via internet sources and have been labeld as
    abandonware. They have been included in this distribution for educational
    purposes only and this copyright notice does not attempt to claim any
    ownership of this material.
*/

#include "GameModel.h"
#include "Debug.h"

// Normal capabilities

/**
 *
 * @class CPlayerCapabilityMove
 *
 * @ brief This class was written to give palayer capability of move \n
 *   <pre>
 *    The class contains two other clases which are CRegistrant and CActivatedCapability.
 *    They are resposible for determining the player who should move and activation of
 *    cabability. The class also keep tracks of precentge compelation of the capability
 *    the steps and cancelation of capability.
 *   </pre>
 * @author Seza
 *
 * @version 1.0
 *
 * @date 10/13/2017 21:04:00
 *
 * Contact: shabibi@ucdavis.edu
 * 
 */
class CPlayerCapabilityMove : public CPlayerCapability{
    protected:

        /**
         *
         *@class CRegistrant
         *
         * @brief the class was written to determine the player who should get the capability
         *
         * @author Seza
         *
         * @version 1.0
         *
         * @date 10/13/2017 23:17:00
         *
         * Contact: shabibi@ucdavis.edu
         */
        class CRegistrant{
            public:
                CRegistrant();
        };
        static CRegistrant DRegistrant;

        /**
         *
         *@class CActivatedCapability
         *
         * @brief the class was written to activate the player capability
         *     <pre>
         *      The class is resposible for showing the precentage completation until
         *      the player get the capabiltiy,following steps to get capability, and
         *      cancelation of capability.
         *     </pre>
         * @author Seza
         *
         * @version 1.0
         *
         * @date 10/13/2017 23:17:00
         *
         * Contact: shabibi@ucdavis.edu
         */
        class CActivatedCapability : public CActivatedPlayerCapability{
            protected:

            public:
                CActivatedCapability(std::shared_ptr< CPlayerAsset > actor, std::shared_ptr< CPlayerData > playerdata, std::shared_ptr< CPlayerAsset > target);
                virtual ~CActivatedCapability(){};

                int PercentComplete(int max);
                bool IncrementStep();
                void Cancel();
        };
        CPlayerCapabilityMove();

    public:
        virtual ~CPlayerCapabilityMove(){};
        
        bool CanInitiate(std::shared_ptr< CPlayerAsset > actor, std::shared_ptr< CPlayerData > playerdata);
        bool CanApply(std::shared_ptr< CPlayerAsset > actor, std::shared_ptr< CPlayerData > playerdata, std::shared_ptr< CPlayerAsset > target);
        bool ApplyCapability(std::shared_ptr< CPlayerAsset > actor, std::shared_ptr< CPlayerData > playerdata, std::shared_ptr< CPlayerAsset > target);
};

CPlayerCapabilityMove::CRegistrant CPlayerCapabilityMove::DRegistrant;

CPlayerCapabilityMove::CRegistrant::CRegistrant(){
    CPlayerCapability::Register(std::shared_ptr< CPlayerCapabilityMove >(new CPlayerCapabilityMove()));   
}

CPlayerCapabilityMove::CPlayerCapabilityMove() : CPlayerCapability(std::string("Move"), ETargetType::TerrainOrAsset){

}

/**
* it will check if the actor can gain/ initiate capability.
*
* @param[in] actor shar pointer to the class of PlayerAsset.
* @param[in] playerdata  share pointer to the class of PlayerData
*
* @return boolian function if the acter can intiate capability or not
*
*/
bool CPlayerCapabilityMove::CanInitiate(std::shared_ptr< CPlayerAsset > actor, std::shared_ptr< CPlayerData > playerdata){
    return actor->Speed() > 0;
}

/**
* it will check if capability can be apply to the actor. condition in this case actore's speed > 0.
*
* @param[in] actor share pointer to the class of PlayerAsset.
* @param[in] playerdata  share pointer to the class of PlayerData
* @param[in] playerdata  share pointer to the class of PlayerAsset
*
* @return boolian function if the acter can be applied for capability
*
*/
bool CPlayerCapabilityMove::CanApply(std::shared_ptr< CPlayerAsset > actor, std::shared_ptr< CPlayerData > playerdata, std::shared_ptr< CPlayerAsset > target){
    return actor->Speed() > 0;
}

/**
* set acter a new capability. using a struct and PushCommand function
*
* @param[in] actor share pointer to the class of PlayerAsset.
* @param[in] playerdata  share pointer to the class of PlayerData
* @param[in] playerdata  share pointer to the class of PlayerAsset
*
* @return boolian function if the actor got apability or not.
*
*/
bool CPlayerCapabilityMove::ApplyCapability(std::shared_ptr< CPlayerAsset > actor, std::shared_ptr< CPlayerData > playerdata, std::shared_ptr< CPlayerAsset > target){
    if(actor->TilePosition() != target->TilePosition()){
        SAssetCommand NewCommand;

        NewCommand.DAction = EAssetAction::Capability;
        NewCommand.DCapability = AssetCapabilityType();
        NewCommand.DAssetTarget = target;
        NewCommand.DActivatedCapability = std::make_shared< CActivatedCapability >(actor, playerdata, target);
        actor->ClearCommand();
        actor->PushCommand(NewCommand);
        return true;
    }

    return false;
}

CPlayerCapabilityMove::CActivatedCapability::CActivatedCapability(std::shared_ptr< CPlayerAsset > actor, std::shared_ptr< CPlayerData > playerdata, std::shared_ptr< CPlayerAsset > target) :
CActivatedPlayerCapability(actor, playerdata, target){

}

/**
* show the precentage completation of the capability.
*
* @param[in] max the number of max percent complete.
*
* @return number of perscentage compelete.
*
*/
int CPlayerCapabilityMove::CActivatedCapability::PercentComplete(int max){
    return 0;
}

/**
* Set/initilize the next step.
*
* @brief it uses two struct to Acknowledgethe actor and make the command to gain
*         capability.
*
* @param[in] it does not have a parameter.
*
* @return bool function if actore gain the capability or not.
*
*/
bool CPlayerCapabilityMove::CActivatedCapability::IncrementStep(){
    SAssetCommand AssetCommand;
    SGameEvent TempEvent;

    TempEvent.DType = EEventType::Acknowledge;
    TempEvent.DAsset = DActor;
    DPlayerData->AddGameEvent(TempEvent);
        
    AssetCommand.DAction = EAssetAction::Walk;
    AssetCommand.DAssetTarget = DTarget;
    if(!DActor->TileAligned()){
        DActor->Direction(DirectionOpposite(DActor->Position().TileOctant()));
    }
    DActor->ClearCommand();
    DActor->PushCommand(AssetCommand);
    return true;
}

/**
* cancel the capability of the actor.
*
* @param[in] it does not have a parameter.
*
* @return return nothing.
*
*/
void CPlayerCapabilityMove::CActivatedCapability::Cancel(){

    DActor->PopCommand();
}

/**
 *
 * @class CPlayerCapabilityMineHarvest
 *
 * @ brief This class was written to give palayer capability of MineHarvest \n
 *     <pre>
 *    The class contains two other clases which are CRegistrant and CActivatedCapability.
 *    They are resposible for determining the player who should do Mine Harvest and activation of
 *    cabability. The class also keep tracks of precentge compelation of the capability
 *    the steps and cancelation of capability.
 *     </pre>
 * @author Seza
 *
 * @version 1.0
 *
 * @date 10/13/2017 21:04:00
 *
 * Contact: shabibi@ucdavis.edu
 *
 */
class CPlayerCapabilityMineHarvest : public CPlayerCapability{
    protected:

      /**
       *
       *@class CRegistrant
       *
       * @brief the class was written to determine the player who should get the capability
       *
       * @author Seza
       *
       * @version 1.0
       *
       * @date 10/13/2017 23:17:00
       *
       * Contact: shabibi@ucdavis.edu
       */
        class CRegistrant{
            public:
                CRegistrant();
        };
        static CRegistrant DRegistrant;

        /**
         *
         *@class CActivatedCapability
         *
         * @brief the class was written to activate the player capability
         *     <pre>
         *      The class is resposible for showing the precentage completation until
         *      the player get the capabiltiy,following steps to get capability, and
         *      cancelation of capability.
         *     </pre>
         * @author Seza
         *
         * @version 1.0
         *
         * @date 10/13/2017 23:17:00
         *
         * Contact: shabibi@ucdavis.edu
         */
        class CActivatedCapability : public CActivatedPlayerCapability{
            protected:

            public:
                CActivatedCapability(std::shared_ptr< CPlayerAsset > actor, std::shared_ptr< CPlayerData > playerdata, std::shared_ptr< CPlayerAsset > target);
                virtual ~CActivatedCapability(){};

                int PercentComplete(int max);
                bool IncrementStep();
                void Cancel();
        };
        CPlayerCapabilityMineHarvest();

    public:
        virtual ~CPlayerCapabilityMineHarvest(){};

        bool CanInitiate(std::shared_ptr< CPlayerAsset > actor, std::shared_ptr< CPlayerData > playerdata);
        bool CanApply(std::shared_ptr< CPlayerAsset > actor, std::shared_ptr< CPlayerData > playerdata, std::shared_ptr< CPlayerAsset > target);
        bool ApplyCapability(std::shared_ptr< CPlayerAsset > actor, std::shared_ptr< CPlayerData > playerdata, std::shared_ptr< CPlayerAsset > target);
};

CPlayerCapabilityMineHarvest::CRegistrant CPlayerCapabilityMineHarvest::DRegistrant;

CPlayerCapabilityMineHarvest::CRegistrant::CRegistrant(){
    CPlayerCapability::Register(std::shared_ptr< CPlayerCapabilityMineHarvest >(new CPlayerCapabilityMineHarvest()));
}

CPlayerCapabilityMineHarvest::CPlayerCapabilityMineHarvest() : CPlayerCapability(std::string("Mine"), ETargetType::TerrainOrAsset){

}

/**
* it will check if the actor can gain/ initiate capability.
*
* @param[in] actor share pointer to the class of PlayerAsset.
* @param[in] playerdata  share pointer to the class of PlayerData
*
* @return boolian function if the actor can intiate capability or not
*
*/
bool CPlayerCapabilityMineHarvest::CanInitiate(std::shared_ptr< CPlayerAsset > actor, std::shared_ptr< CPlayerData > playerdata){
    return actor->HasCapability(EAssetCapabilityType::Mine);
}

/**
* it will check if capability can be apply to the actor. condition in this case\n
*     <pre>
*     the actor must have a capability of mine.
*     the actor must not be a Lumber or Gold.
*     the targettype must not be GoldMine
*     </pre
*
* @param[in] actor share pointer to the class of PlayerAsset.
* @param[in] playerdata  share pointer to the class of PlayerData
* @param[in] playerdata  share pointer to the class of PlayerAsset
*
* @return boolian function if the actor can be can be applied for capability
*
*/
bool CPlayerCapabilityMineHarvest::CanApply(std::shared_ptr< CPlayerAsset > actor, std::shared_ptr< CPlayerData > playerdata, std::shared_ptr< CPlayerAsset > target){

    if(!actor->HasCapability(EAssetCapabilityType::Mine)){
        return false;
    }
    if(actor->Lumber()||actor->Gold()){
        return false;
    }
    if(EAssetType::GoldMine == target->Type()){
        return true;
    }
    if(EAssetType::None != target->Type()){
        return false;
    }
    return CTerrainMap::ETileType::Forest == playerdata->PlayerMap()->TileType(target->TilePosition());
}

/**
* set acter a new capability. using a struct and PushCommand function
*
* @param[in] actor share pointer to the class of PlayerAsset.
* @param[in] playerdata  share pointer to the class of PlayerData
* @param[in] playerdata  share pointer to the class of PlayerAsset
*
* @return boolian function if the actor got apability or not.
*
*/
bool CPlayerCapabilityMineHarvest::ApplyCapability(std::shared_ptr< CPlayerAsset > actor, std::shared_ptr< CPlayerData > playerdata, std::shared_ptr< CPlayerAsset > target){
    SAssetCommand NewCommand;

    NewCommand.DAction = EAssetAction::Capability;
    NewCommand.DCapability = AssetCapabilityType();
    NewCommand.DAssetTarget = target;
    NewCommand.DActivatedCapability = std::make_shared< CActivatedCapability >(actor, playerdata, target);
    actor->ClearCommand();
    actor->PushCommand(NewCommand);

    return true;
}

CPlayerCapabilityMineHarvest::CActivatedCapability::CActivatedCapability(std::shared_ptr< CPlayerAsset > actor, std::shared_ptr< CPlayerData > playerdata, std::shared_ptr< CPlayerAsset > target) :
CActivatedPlayerCapability(actor, playerdata, target){

}

/**
* show the precentage completation of the capability.
*
* @param[in] max the number of max percent complete.
*
* @return number of perscentage compelete.
*
*/
int CPlayerCapabilityMineHarvest::CActivatedCapability::PercentComplete(int max){
    return 0;
}

/**
* Set/initilize the next step.
*
* @brief it uses two struct to Acknowledgethe actor and make the command to gain
*         capability.
*
* @param[in] it does not have a parameter.
*
* @return bool function if actore gain the capability or not.
*
*/
bool CPlayerCapabilityMineHarvest::CActivatedCapability::IncrementStep(){
    SAssetCommand AssetCommand;
    SGameEvent TempEvent;

    TempEvent.DType = EEventType::Acknowledge;
    TempEvent.DAsset = DActor;
    DPlayerData->AddGameEvent(TempEvent);

    AssetCommand.DAssetTarget = DTarget;
    if(EAssetType::GoldMine == DTarget->Type()){
        AssetCommand.DAction = EAssetAction::MineGold;
    }
    else{
        AssetCommand.DAction = EAssetAction::HarvestLumber;
    }
    DActor->ClearCommand();
    DActor->PushCommand(AssetCommand);
    AssetCommand.DAction = EAssetAction::Walk;
    if(!DActor->TileAligned()){
        DActor->Direction(DirectionOpposite(DActor->Position().TileOctant()));
    }
    DActor->PushCommand(AssetCommand);
    return true;
}

/**
* cancel the capability of the actor.
*
* @param[in] it does not have a parameter.
*
* @return return nothing.
*
*/
void CPlayerCapabilityMineHarvest::CActivatedCapability::Cancel(){

    DActor->PopCommand();
}

/**
 *
 * @class CPlayerCapabilityStandGround
 *
 * @ brief This class was written to give palayer capability of StandGround \n
 *     <pre>
 *    The class contains two other clases which are CRegistrant and CActivatedCapability.
 *    They are resposible for determining the player who should do StandGround and activation of
 *    cabability. The class also keep tracks of precentge compelation of the capability
 *    the steps and cancelation of capability.
 *     </pre>
 * @author Seza
 *
 * @version 1.0
 *
 * @date 10/13/2017 21:04:00
 *
 * Contact: shabibi@ucdavis.edu
 *
 */
class CPlayerCapabilityStandGround : public CPlayerCapability{
    protected:

      /**
       *
       *@class CRegistrant
       *
       * @brief the class was written to determine the player who should get the capability
       *
       * @author Seza
       *
       * @version 1.0
       *
       * @date 10/13/2017 23:17:00
       *
       * Contact: shabibi@ucdavis.edu
       */
        class CRegistrant{
            public:
                CRegistrant();
        };
        static CRegistrant DRegistrant;

        /**
         *
         *@class CActivatedCapability
         *
         * @brief the class was written to activate the player capability
         *     <pre>
         *      The class is resposible for showing the precentage completation until
         *      the player get the capabiltiy,following steps to get capability, and
         *      cancelation of capability.
         *     </pre>
         * @author Seza
         *
         * @version 1.0
         *
         * @date 10/13/2017 23:17:00
         *
         * Contact: shabibi@ucdavis.edu
         */
        class CActivatedCapability : public CActivatedPlayerCapability{
            protected:

            public:
                CActivatedCapability(std::shared_ptr< CPlayerAsset > actor, std::shared_ptr< CPlayerData > playerdata, std::shared_ptr< CPlayerAsset > target);
                virtual ~CActivatedCapability(){};

                int PercentComplete(int max);
                bool IncrementStep();
                void Cancel();
        };
        CPlayerCapabilityStandGround();

    public:
        virtual ~CPlayerCapabilityStandGround(){};

        bool CanInitiate(std::shared_ptr< CPlayerAsset > actor, std::shared_ptr< CPlayerData > playerdata);
        bool CanApply(std::shared_ptr< CPlayerAsset > actor, std::shared_ptr< CPlayerData > playerdata, std::shared_ptr< CPlayerAsset > target);
        bool ApplyCapability(std::shared_ptr< CPlayerAsset > actor, std::shared_ptr< CPlayerData > playerdata, std::shared_ptr< CPlayerAsset > target);
};

CPlayerCapabilityStandGround::CRegistrant CPlayerCapabilityStandGround::DRegistrant;

CPlayerCapabilityStandGround::CRegistrant::CRegistrant(){
    CPlayerCapability::Register(std::shared_ptr< CPlayerCapabilityStandGround >(new CPlayerCapabilityStandGround()));   
}

CPlayerCapabilityStandGround::CPlayerCapabilityStandGround() : CPlayerCapability(std::string("StandGround"), ETargetType::None){

}

/**
* it will check if the actor can gain/ initiate capability.
*
* @param[in] actor shar pointer to the class of PlayerAsset.
* @param[in] playerdata  share pointer to the class of PlayerData
*
* @return boolian function if the acter can intiate capability or not
*
*/
bool CPlayerCapabilityStandGround::CanInitiate(std::shared_ptr< CPlayerAsset > actor, std::shared_ptr< CPlayerData > playerdata){
    return true;
}

/**
* it will check if capability can be apply to the actor. it does not have condition\n
*
* @param[in] actor share pointer to the class of PlayerAsset.
* @param[in] playerdata  share pointer to the class of PlayerData
* @param[in] playerdata  share pointer to the class of PlayerAsset
*
* @return always return true
*
*/
bool CPlayerCapabilityStandGround::CanApply(std::shared_ptr< CPlayerAsset > actor, std::shared_ptr< CPlayerData > playerdata, std::shared_ptr< CPlayerAsset > target){

    return true;
}

/**
* set acter a new capability. using a struct and PushCommand function
*
* @param[in] actor share pointer to the class of PlayerAsset.
* @param[in] playerdata  share pointer to the class of PlayerData
* @param[in] playerdata  share pointer to the class of PlayerAsset
*
* @return boolian function if the actor got apability or not.
*
*/
bool CPlayerCapabilityStandGround::ApplyCapability(std::shared_ptr< CPlayerAsset > actor, std::shared_ptr< CPlayerData > playerdata, std::shared_ptr< CPlayerAsset > target){
    SAssetCommand NewCommand;

    NewCommand.DAction = EAssetAction::Capability;
    NewCommand.DCapability = AssetCapabilityType();
    NewCommand.DAssetTarget = target;
    NewCommand.DActivatedCapability = std::make_shared< CActivatedCapability >(actor, playerdata, target);
    actor->ClearCommand();
    actor->PushCommand(NewCommand);

    return true;
}

CPlayerCapabilityStandGround::CActivatedCapability::CActivatedCapability(std::shared_ptr< CPlayerAsset > actor, std::shared_ptr< CPlayerData > playerdata, std::shared_ptr< CPlayerAsset > target) :
CActivatedPlayerCapability(actor, playerdata, target){

}

/**
* show the precentage completation of the capability.
*
* @param[in] max the number of max percent complete.
*
* @return number of perscentage compelete.
*
*/
int CPlayerCapabilityStandGround::CActivatedCapability::PercentComplete(int max){
    return 0;
}

/**
* Set/initilize the next step.
*
* @brief it uses two struct to Acknowledgethe actor and make the command to gain
*         capability.
*
* @param[in] it does not have a parameter.
*
* @return bool function if actore gain the capability or not.
*
*/
bool CPlayerCapabilityStandGround::CActivatedCapability::IncrementStep(){
    SAssetCommand AssetCommand;
    SGameEvent TempEvent;

    TempEvent.DType = EEventType::Acknowledge;
    TempEvent.DAsset = DActor;
    DPlayerData->AddGameEvent(TempEvent);

    AssetCommand.DAssetTarget = DPlayerData->CreateMarker(DActor->Position(), false);
    AssetCommand.DAction = EAssetAction::StandGround;

    DActor->ClearCommand();
    DActor->PushCommand(AssetCommand);

    if(!DActor->TileAligned()){
        AssetCommand.DAction = EAssetAction::Walk;
        DActor->Direction(DirectionOpposite(DActor->Position().TileOctant()));
        DActor->PushCommand(AssetCommand);
    }

    return true;
}

/**
* cancel the capability of the actor.
*
* @param[in] it does not have a parameter.
*
* @return return nothing.
*
*/
void CPlayerCapabilityStandGround::CActivatedCapability::Cancel(){

    DActor->PopCommand();
}

/**
 *
 * @class CPlayerCapabilityCancel
 *
 * @ brief This class was written to give palayer capability of Cancelation \n
 *     <pre>
 *    The class contains two other clases which are CRegistrant and CActivatedCapability.
 *    They are resposible for determining the player whose cabability should be cancel and activation of
 *    cabability. The class also keep tracks of precentge compelation of the cancelation
 *    the steps and cancelation of capability.
 *     </pre>
 * @author Seza
 *
 * @version 1.0
 *
 * @date 10/13/2017 21:04:00
 *
 * Contact: shabibi@ucdavis.edu
 *
 */
class CPlayerCapabilityCancel : public CPlayerCapability{
    protected:

      /**
       *
       *@class CRegistrant
       *
       * @brief the class was written to determine the player who should get the capability
       *
       * @author Seza
       *
       * @version 1.0
       *
       * @date 10/13/2017 23:17:00
       *
       * Contact: shabibi@ucdavis.edu
       */
        class CRegistrant{
            public:
                CRegistrant();
        };
        static CRegistrant DRegistrant;

        /**
         *
         *@class CActivatedCapability
         *
         * @brief the class was written to activate the player capability
         *     <pre>
         *      The class is resposible for showing the precentage completation until
         *      the player get the capabiltiy,following steps to get capability, and
         *      cancelation of capability.
         *     </pre>
         * @author Seza
         *
         * @version 1.0
         *
         * @date 10/13/2017 23:17:00
         *
         * Contact: shabibi@ucdavis.edu
         */
        class CActivatedCapability : public CActivatedPlayerCapability{
            protected:

            public:
                CActivatedCapability(std::shared_ptr< CPlayerAsset > actor, std::shared_ptr< CPlayerData > playerdata, std::shared_ptr< CPlayerAsset > target);
                virtual ~CActivatedCapability(){};

                int PercentComplete(int max);
                bool IncrementStep();
                void Cancel();
        };
        CPlayerCapabilityCancel();

    public:
        virtual ~CPlayerCapabilityCancel(){};

        bool CanInitiate(std::shared_ptr< CPlayerAsset > actor, std::shared_ptr< CPlayerData > playerdata);
        bool CanApply(std::shared_ptr< CPlayerAsset > actor, std::shared_ptr< CPlayerData > playerdata, std::shared_ptr< CPlayerAsset > target);
        bool ApplyCapability(std::shared_ptr< CPlayerAsset > actor, std::shared_ptr< CPlayerData > playerdata, std::shared_ptr< CPlayerAsset > target);
};

CPlayerCapabilityCancel::CRegistrant CPlayerCapabilityCancel::DRegistrant;

CPlayerCapabilityCancel::CRegistrant::CRegistrant(){
    CPlayerCapability::Register(std::shared_ptr< CPlayerCapabilityCancel >(new CPlayerCapabilityCancel()));
}

CPlayerCapabilityCancel::CPlayerCapabilityCancel() : CPlayerCapability(std::string("Cancel"), ETargetType::None){

}

/**
* it will check if the actor can gain/ initiate capability.
*
* @param[in] actor shar pointer to the class of PlayerAsset.
* @param[in] playerdata  share pointer to the class of PlayerData
*
* @return boolian function if the acter can intiate capability or not
*
*/
bool CPlayerCapabilityCancel::CanInitiate(std::shared_ptr< CPlayerAsset > actor, std::shared_ptr< CPlayerData > playerdata){
    return true;
}

/**
* it will check if capability can be apply to the actor .
*
* @param[in] actor share pointer to the class of PlayerAsset.
* @param[in] playerdata  share pointer to the class of PlayerData
* @param[in] playerdata  share pointer to the class of PlayerAsset
*
* @return always return true
*
*/
bool CPlayerCapabilityCancel::CanApply(std::shared_ptr< CPlayerAsset > actor, std::shared_ptr< CPlayerData > playerdata, std::shared_ptr< CPlayerAsset > target){
    return true;
}

/**
* set acter a new capability. using a struct and PushCommand function
*
* @param[in] actor share pointer to the class of PlayerAsset.
* @param[in] playerdata  share pointer to the class of PlayerData
* @param[in] playerdata  share pointer to the class of PlayerAsset
*
* @return boolian function if the actor got apability or not.
*
*/
bool CPlayerCapabilityCancel::ApplyCapability(std::shared_ptr< CPlayerAsset > actor, std::shared_ptr< CPlayerData > playerdata, std::shared_ptr< CPlayerAsset > target){
    SAssetCommand NewCommand;

    NewCommand.DAction = EAssetAction::Capability;
    NewCommand.DCapability = AssetCapabilityType();
    NewCommand.DAssetTarget = target;
    NewCommand.DActivatedCapability = std::make_shared< CActivatedCapability >(actor, playerdata, target);
    actor->PushCommand(NewCommand);

    return true;
}

CPlayerCapabilityCancel::CActivatedCapability::CActivatedCapability(std::shared_ptr< CPlayerAsset > actor, std::shared_ptr< CPlayerData > playerdata, std::shared_ptr< CPlayerAsset > target) :
CActivatedPlayerCapability(actor, playerdata, target){

}

/**
* show the precentage completation of the capability.
*
* @param[in] max the number of max percent complete.
*
* @return number of perscentage compelete.
*
*/
int CPlayerCapabilityCancel::CActivatedCapability::PercentComplete(int max){
    return 0;
}

/**
* Set/initilize the next step.
*
* @brief it uses two struct to Acknowledgethe actor and make the command to gain
*         capability.
*
* @param[in] it does not have a parameter.
*
* @return bool function if actore gain the capability or not.
*
*/
bool CPlayerCapabilityCancel::CActivatedCapability::IncrementStep(){
    DActor->PopCommand();

    if(EAssetAction::None != DActor->Action()){
        SAssetCommand AssetCommand;

        AssetCommand = DActor->CurrentCommand();
        if(EAssetAction::Construct == AssetCommand.DAction){
            if(AssetCommand.DAssetTarget){
                AssetCommand.DAssetTarget->CurrentCommand().DActivatedCapability->Cancel();
            }
            else if(AssetCommand.DActivatedCapability){
                AssetCommand.DActivatedCapability->Cancel();
            }
        }
        else if(AssetCommand.DActivatedCapability){
            AssetCommand.DActivatedCapability->Cancel();
        }
    }

    return true;
}

/**
* cancel the capability of the actor.
*
* @param[in] it does not have a parameter.
*
* @return return nothing.
*
*/
void CPlayerCapabilityCancel::CActivatedCapability::Cancel(){

    DActor->PopCommand();
}

/**
 *
 * @class CPlayerCapabilityConvey
 *
 * @ brief This class was written to give palayer capability to Convey \n
 *     <pre>
 *    The class contains two other clases which are CRegistrant and CActivatedCapability.
 *    They are resposible for determining the player who should get the cabability and activation of
 *    cabability. The class also keep tracks of precentge compelation of the capability
 *    the steps and cancelation of capability.
 *     </pre>
 * @author Seza
 *
 * @version 1.0
 *
 * @date 10/13/2017 21:04:00
 *
 * Contact: shabibi@ucdavis.edu
 *
 */
class CPlayerCapabilityConvey : public CPlayerCapability{
    protected:

      /**
       *
       *@class CRegistrant
       *
       * @brief the class was written to determine the player who should get the capability
       *
       * @author Seza
       *
       * @version 1.0
       *
       * @date 10/13/2017 23:17:00
       *
       * Contact: shabibi@ucdavis.edu
       */
        class CRegistrant{
            public:
                CRegistrant();
        };
        static CRegistrant DRegistrant;

        /**
         *
         *@class CActivatedCapability
         *
         * @brief the class was written to activate the player capability
         *     <pre>
         *      The class is resposible for showing the precentage completation until
         *      the player get the capabiltiy,following steps to get capability, and
         *      cancelation of capability.
         *     </pre>
         * @author Seza
         *
         * @version 1.0
         *
         * @date 10/13/2017 23:17:00
         *
         * Contact: shabibi@ucdavis.edu
         */
        class CActivatedCapability : public CActivatedPlayerCapability{
            protected:

            public:
                CActivatedCapability(std::shared_ptr< CPlayerAsset > actor, std::shared_ptr< CPlayerData > playerdata, std::shared_ptr< CPlayerAsset > target);
                virtual ~CActivatedCapability(){};

                int PercentComplete(int max);
                bool IncrementStep();
                void Cancel();
        };
        CPlayerCapabilityConvey();

    public:
        virtual ~CPlayerCapabilityConvey(){};

        bool CanInitiate(std::shared_ptr< CPlayerAsset > actor, std::shared_ptr< CPlayerData > playerdata);
        bool CanApply(std::shared_ptr< CPlayerAsset > actor, std::shared_ptr< CPlayerData > playerdata, std::shared_ptr< CPlayerAsset > target);
        bool ApplyCapability(std::shared_ptr< CPlayerAsset > actor, std::shared_ptr< CPlayerData > playerdata, std::shared_ptr< CPlayerAsset > target);
};

CPlayerCapabilityConvey::CRegistrant CPlayerCapabilityConvey::DRegistrant;

CPlayerCapabilityConvey::CRegistrant::CRegistrant(){
    CPlayerCapability::Register(std::shared_ptr< CPlayerCapabilityConvey >(new CPlayerCapabilityConvey()));
}

CPlayerCapabilityConvey::CPlayerCapabilityConvey() : CPlayerCapability(std::string("Convey"), ETargetType::Asset){

}

/**
* it will check if the actor can gain/ initiate capability.
*
* @param[in] actor shar pointer to the class of PlayerAsset.
* @param[in] playerdata  share pointer to the class of PlayerData
*
* @return boolian function if the acter can intiate capability or not
*
*/
bool CPlayerCapabilityConvey::CanInitiate(std::shared_ptr< CPlayerAsset > actor, std::shared_ptr< CPlayerData > playerdata){
    return actor->Speed() > 0 && (actor->Lumber() || actor->Gold());
}

/**
* it will check if capability can be apply to the actor. condition in this case\n
*     <pre>
*     the actor has speed, and it is a lumber or gold it must not doing construction.
*     if target type be TownHall, Keep , and Castle it returns true .
*     if the actor is Lumber and targettypeis LumberMill it returns true.
*    </pre>
*
* @param[in] actor share pointer to the class of PlayerAsset.
* @param[in] playerdata  share pointer to the class of PlayerData
* @param[in] playerdata  share pointer to the class of PlayerAsset
*
* @return boolian function if the acter can be can be applied for capability
*
*/
bool CPlayerCapabilityConvey::CanApply(std::shared_ptr< CPlayerAsset > actor, std::shared_ptr< CPlayerData > playerdata, std::shared_ptr< CPlayerAsset > target){

    if(actor->Speed() && (actor->Lumber() || actor->Gold())){
        if(EAssetAction::Construct == target->Action()){
            return false;
        }
        if((EAssetType::TownHall == target->Type())||(EAssetType::Keep == target->Type())||(EAssetType::Castle == target->Type())){
            return true;
        }
        if(actor->Lumber() && (EAssetType::LumberMill == target->Type())){
            return true;
        }
    }
    return false;
}

/**
* set acter a new capability. using a struct and PushCommand function
*
* @param[in] actor share pointer to the class of PlayerAsset.
* @param[in] playerdata  share pointer to the class of PlayerData
* @param[in] playerdata  share pointer to the class of PlayerAsset
*
* @return boolian function if the actor got apability or not.
*
*/
bool CPlayerCapabilityConvey::ApplyCapability(std::shared_ptr< CPlayerAsset > actor, std::shared_ptr< CPlayerData > playerdata, std::shared_ptr< CPlayerAsset > target){
    SAssetCommand NewCommand;

    NewCommand.DAction = EAssetAction::Capability;
    NewCommand.DCapability = AssetCapabilityType();
    NewCommand.DAssetTarget = target;
    NewCommand.DActivatedCapability = std::make_shared< CActivatedCapability >(actor, playerdata, target);
    actor->ClearCommand();
    actor->PushCommand(NewCommand);
    return true;
}

CPlayerCapabilityConvey::CActivatedCapability::CActivatedCapability(std::shared_ptr< CPlayerAsset > actor, std::shared_ptr< CPlayerData > playerdata, std::shared_ptr< CPlayerAsset > target) :
CActivatedPlayerCapability(actor, playerdata, target){

}

/**
* show the precentage completation of the capability.
*
* @param[in] max the number of max percent complete.
*
* @return number of perscentage compelete.
*
*/
int CPlayerCapabilityConvey::CActivatedCapability::PercentComplete(int max){
    return 0;
}

/**
* Set/initilize the next step.
*
* @brief it uses two struct to Acknowledge the actor and make the command to gain
*         capability.
*
* @param[in] it does not have a parameter.
*
* @return bool function if actore gain the capability or not.
*
*/
bool CPlayerCapabilityConvey::CActivatedCapability::IncrementStep(){
    std::weak_ptr< CPlayerAsset > NearestRepository;
    SAssetCommand AssetCommand;
    SGameEvent TempEvent;

    TempEvent.DType = EEventType::Acknowledge;
    TempEvent.DAsset = DActor;
    DPlayerData->AddGameEvent(TempEvent);

    DActor->PopCommand();
    if(DActor->Lumber()){
        AssetCommand.DAction = EAssetAction::ConveyLumber;
        AssetCommand.DAssetTarget = DTarget;
        DActor->PushCommand(AssetCommand);
        AssetCommand.DAction = EAssetAction::Walk;
        DActor->PushCommand(AssetCommand);
        DActor->ResetStep();
    }
    else if(DActor->Gold()){
        AssetCommand.DAction = EAssetAction::ConveyGold;
        AssetCommand.DAssetTarget = DTarget;
        DActor->PushCommand(AssetCommand);
        AssetCommand.DAction = EAssetAction::Walk;
        DActor->PushCommand(AssetCommand);
        DActor->ResetStep();
    }

    return true;
}

/**
* cancel the capability of the actor.
*
* @param[in] it does not have a parameter.
*
* @return return nothing.
*
*/
void CPlayerCapabilityConvey::CActivatedCapability::Cancel(){

    DActor->PopCommand();
}

/**
 *
 * @class CPlayerCapabilityPatrol
 *
 * @ brief This class was written to give palayer capability to Patrol \n
 *     <pre>
 *    The class contains two other clases which are CRegistrant and CActivatedCapability.
 *    They are resposible for determining the player who should get the cabability and activation of
 *    cabability. The class also keep tracks of precentge compelation of the capability
 *    the steps and cancelation of capability.
 *     </pre>
 * @author Seza
 *
 * @version 1.0
 *
 * @date 10/13/2017 21:04:00
 *
 * Contact: shabibi@ucdavis.edu
 *
 */
class CPlayerCapabilityPatrol : public CPlayerCapability{
    protected:

      /**
       *
       *@class CRegistrant
       *
       * @brief the class was written to determine the player who should get the capability
       *
       * @author Seza
       *
       * @version 1.0
       *
       * @date 10/13/2017 23:17:00
       *
       * Contact: shabibi@ucdavis.edu
       */
        class CRegistrant{
            public:
                CRegistrant();
        };
        static CRegistrant DRegistrant;

        /**
         *
         *@class CActivatedCapability
         *
         * @brief the class was written to activate the player capability
         *     <pre>
         *      The class is resposible for showing the precentage completation until
         *      the player get the capabiltiy,following steps to get capability, and
         *      cancelation of capability.
         *     </pre>
         * @author Seza
         *
         * @version 1.0
         *
         * @date 10/13/2017 23:17:00
         *
         * Contact: shabibi@ucdavis.edu
         */
        class CActivatedCapability : public CActivatedPlayerCapability{
            protected:

            public:
                CActivatedCapability(std::shared_ptr< CPlayerAsset > actor, std::shared_ptr< CPlayerData > playerdata, std::shared_ptr< CPlayerAsset > target);
                virtual ~CActivatedCapability(){};

                int PercentComplete(int max);
                bool IncrementStep();
                void Cancel();
        };
        CPlayerCapabilityPatrol();

    public:
        virtual ~CPlayerCapabilityPatrol(){};

        bool CanInitiate(std::shared_ptr< CPlayerAsset > actor, std::shared_ptr< CPlayerData > playerdata);
        bool CanApply(std::shared_ptr< CPlayerAsset > actor, std::shared_ptr< CPlayerData > playerdata, std::shared_ptr< CPlayerAsset > target);
        bool ApplyCapability(std::shared_ptr< CPlayerAsset > actor, std::shared_ptr< CPlayerData > playerdata, std::shared_ptr< CPlayerAsset > target);
};

CPlayerCapabilityPatrol::CRegistrant CPlayerCapabilityPatrol::DRegistrant;

CPlayerCapabilityPatrol::CRegistrant::CRegistrant(){
    CPlayerCapability::Register(std::shared_ptr< CPlayerCapabilityPatrol >(new CPlayerCapabilityPatrol()));
}

CPlayerCapabilityPatrol::CPlayerCapabilityPatrol() : CPlayerCapability(std::string("Patrol"), ETargetType::Terrain){

}

/**
* it will check if the actor can gain/ initiate capability.
*
* @param[in] actor shar pointer to the class of PlayerAsset.
* @param[in] playerdata  share pointer to the class of PlayerData
*
* @return boolian function if the acter can intiate capability or not
*
*/
bool CPlayerCapabilityPatrol::CanInitiate(std::shared_ptr< CPlayerAsset > actor, std::shared_ptr< CPlayerData > playerdata){
    return actor->Speed() > 0;
}

/**
* it will check if capability can be apply to the actor. condition in this case actore's speed > 0.
*
* @param[in] actor share pointer to the class of PlayerAsset.
* @param[in] playerdata  share pointer to the class of PlayerData
* @param[in] playerdata  share pointer to the class of PlayerAsset
*
* @return boolian function if the acter can be applied for capability
*
*/
bool CPlayerCapabilityPatrol::CanApply(std::shared_ptr< CPlayerAsset > actor, std::shared_ptr< CPlayerData > playerdata, std::shared_ptr< CPlayerAsset > target){
    return actor->Speed() > 0;
}

/**
* set acter a new capability. using a struct and PushCommand function
*
* @param[in] actor share pointer to the class of PlayerAsset.
* @param[in] playerdata  share pointer to the class of PlayerData
* @param[in] playerdata  share pointer to the class of PlayerAsset
*
* @return boolian function if the actor got apability or not.
*
*/
bool CPlayerCapabilityPatrol::ApplyCapability(std::shared_ptr< CPlayerAsset > actor, std::shared_ptr< CPlayerData > playerdata, std::shared_ptr< CPlayerAsset > target){
    if(actor->TilePosition() != target->TilePosition()){
        SAssetCommand NewCommand;

        NewCommand.DAction = EAssetAction::Capability;
        NewCommand.DCapability = AssetCapabilityType();
        NewCommand.DAssetTarget = target;
        NewCommand.DActivatedCapability = std::make_shared< CActivatedCapability >(actor, playerdata, target);
        actor->ClearCommand();
        actor->PushCommand(NewCommand);
        return true;
    }

    return false;
}

CPlayerCapabilityPatrol::CActivatedCapability::CActivatedCapability(std::shared_ptr< CPlayerAsset > actor, std::shared_ptr< CPlayerData > playerdata, std::shared_ptr< CPlayerAsset > target) :
CActivatedPlayerCapability(actor, playerdata, target){

}

/**
* show the precentage completation of the capability.
*
* @param[in] max the number of max percent complete.
*
* @return number of perscentage compelete.
*
*/
int CPlayerCapabilityPatrol::CActivatedCapability::PercentComplete(int max){
    return 0;
}

/**
* Set/initilize the next step.
*
* @brief it uses two struct to Acknowledgethe actor and make the command to gain
*         capability.
*
* @param[in] it does not have a parameter.
*
* @return bool function if actore gain the capability or not.
*
*/
bool CPlayerCapabilityPatrol::CActivatedCapability::IncrementStep(){
    SAssetCommand PatrolCommand, WalkCommand;
    SGameEvent TempEvent;

    TempEvent.DType = EEventType::Acknowledge;
    TempEvent.DAsset = DActor;
    DPlayerData->AddGameEvent(TempEvent);

    PatrolCommand.DAction = EAssetAction::Capability;
    PatrolCommand.DCapability = EAssetCapabilityType::Patrol;
    PatrolCommand.DAssetTarget = DPlayerData->CreateMarker(DActor->Position(), false);
    PatrolCommand.DActivatedCapability = std::make_shared< CActivatedCapability >(DActor, DPlayerData, PatrolCommand.DAssetTarget);
    DActor->ClearCommand();
    DActor->PushCommand(PatrolCommand);

    WalkCommand.DAction = EAssetAction::Walk;
    WalkCommand.DAssetTarget = DTarget;
    if(!DActor->TileAligned()){
        DActor->Direction(DirectionOpposite(DActor->Position().TileOctant()));
    }
    DActor->PushCommand(WalkCommand);
    return true;
}

/**
* cancel the capability of the actor.
*
* @param[in] it does not have a parameter.
*
* @return return nothing.
*
*/
void CPlayerCapabilityPatrol::CActivatedCapability::Cancel(){

    DActor->PopCommand();
}

/**
 *
 * @class CPlayerCapabilityAttack
 *
 * @ brief This class was written to give palayer capability to Attack \n
 *     <pre>
 *    The class contains two other clases which are CRegistrant and CActivatedCapability.
 *    They are resposible for determining the player who should get the cabability and activation of
 *    cabability. The class also keep tracks of precentge compelation of the capability
 *    the steps and cancelation of capability.
 *     </pre>
 * @author Seza
 *
 * @version 1.0
 *
 * @date 10/13/2017 21:04:00
 *
 * Contact: shabibi@ucdavis.edu
 *
 */
class CPlayerCapabilityAttack : public CPlayerCapability{
    protected:

      /**
       *
       *@class CRegistrant
       *
       * @brief the class was written to determine the player who should get the capability
       *
       * @author Seza
       *
       * @version 1.0
       *
       * @date 10/13/2017 23:17:00
       *
       * Contact: shabibi@ucdavis.edu
       */
        class CRegistrant{
            public:
                CRegistrant();
        };
        static CRegistrant DRegistrant;

        /**
         *
         *@class CActivatedCapability
         *
         * @brief the class was written to activate the player capability
         *     <pre>
         *      The class is resposible for showing the precentage completation until
         *      the player get the capabiltiy,following steps to get capability, and
         *      cancelation of capability.
         *     </pre>
         * @author Seza
         *
         * @version 1.0
         *
         * @date 10/13/2017 23:17:00
         *
         * Contact: shabibi@ucdavis.edu
         */
        class CActivatedCapability : public CActivatedPlayerCapability{
            protected:

            public:
                CActivatedCapability(std::shared_ptr< CPlayerAsset > actor, std::shared_ptr< CPlayerData > playerdata, std::shared_ptr< CPlayerAsset > target);
                virtual ~CActivatedCapability(){};

                int PercentComplete(int max);
                bool IncrementStep();
                void Cancel();
        };
        CPlayerCapabilityAttack();

    public:
        virtual ~CPlayerCapabilityAttack(){};

        bool CanInitiate(std::shared_ptr< CPlayerAsset > actor, std::shared_ptr< CPlayerData > playerdata);
        bool CanApply(std::shared_ptr< CPlayerAsset > actor, std::shared_ptr< CPlayerData > playerdata, std::shared_ptr< CPlayerAsset > target);
        bool ApplyCapability(std::shared_ptr< CPlayerAsset > actor, std::shared_ptr< CPlayerData > playerdata, std::shared_ptr< CPlayerAsset > target);
};

CPlayerCapabilityAttack::CRegistrant CPlayerCapabilityAttack::DRegistrant;

CPlayerCapabilityAttack::CRegistrant::CRegistrant(){
    CPlayerCapability::Register(std::shared_ptr< CPlayerCapabilityAttack >(new CPlayerCapabilityAttack()));
}

CPlayerCapabilityAttack::CPlayerCapabilityAttack() : CPlayerCapability(std::string("Attack"), ETargetType::Asset){

}

/**
* it will check if the actor can gain/ initiate capability.
*
* @param[in] actor shar pointer to the class of PlayerAsset.
* @param[in] playerdata  share pointer to the class of PlayerData
*
* @return boolian function if the acter can intiate capability or not
*
*/
bool CPlayerCapabilityAttack::CanInitiate(std::shared_ptr< CPlayerAsset > actor, std::shared_ptr< CPlayerData > playerdata){
    return actor->Speed() > 0;
}

/**
* it will check if capability can be apply to the actor. condition:
*     <pre>
*     actore's speed > 0.
*     The actor's color must not equal to target color and player color must not equal target color
*     </pre>
* @param[in] actor share pointer to the class of PlayerAsset.
* @param[in] playerdata  share pointer to the class of PlayerData
* @param[in] playerdata  share pointer to the class of PlayerAsset
*
* @return boolian function if the acter can be applied for capability
*
*/
bool CPlayerCapabilityAttack::CanApply(std::shared_ptr< CPlayerAsset > actor, std::shared_ptr< CPlayerData > playerdata, std::shared_ptr< CPlayerAsset > target){
    if((actor->Color() == target->Color())||(EPlayerColor::None == target->Color())){
        return false;   
    }
    return actor->Speed() > 0;
}

/**
* set acter a new capability. using a struct and PushCommand function
*
* @param[in] actor share pointer to the class of PlayerAsset.
* @param[in] playerdata  share pointer to the class of PlayerData
* @param[in] playerdata  share pointer to the class of PlayerAsset
*
* @return boolian function if the actor got apability or not.
*
*/
bool CPlayerCapabilityAttack::ApplyCapability(std::shared_ptr< CPlayerAsset > actor, std::shared_ptr< CPlayerData > playerdata, std::shared_ptr< CPlayerAsset > target){
    if(actor->TilePosition() != target->TilePosition()){
        SAssetCommand NewCommand;

        NewCommand.DAction = EAssetAction::Capability;
        NewCommand.DCapability = AssetCapabilityType();
        NewCommand.DAssetTarget = target;
        NewCommand.DActivatedCapability = std::make_shared< CActivatedCapability >(actor, playerdata, target);
        actor->ClearCommand();
        actor->PushCommand(NewCommand);
        return true;
    }

    return false;
}

CPlayerCapabilityAttack::CActivatedCapability::CActivatedCapability(std::shared_ptr< CPlayerAsset > actor, std::shared_ptr< CPlayerData > playerdata, std::shared_ptr< CPlayerAsset > target) :
CActivatedPlayerCapability(actor, playerdata, target){

}

/**
* show the precentage completation of the capability.
*
* @param[in] max the number of max percent complete.
*
* @return number of perscentage compelete.
*
*/
int CPlayerCapabilityAttack::CActivatedCapability::PercentComplete(int max){
    return 0;
}

/**
* Set/initilize the next step.
*
* @brief it uses two struct to Acknowledgethe actor and make the command to gain
*         capability.
*
* @param[in] it does not have a parameter.
*
* @return bool function if actore gain the capability or not.
*
*/
bool CPlayerCapabilityAttack::CActivatedCapability::IncrementStep(){
    SAssetCommand AssetCommand;
    SGameEvent TempEvent;

    TempEvent.DType = EEventType::Acknowledge;
    TempEvent.DAsset = DActor;
    DPlayerData->AddGameEvent(TempEvent);

    AssetCommand.DAction = EAssetAction::Attack;
    AssetCommand.DAssetTarget = DTarget;
    DActor->ClearCommand();
    DActor->PushCommand(AssetCommand);

    AssetCommand.DAction = EAssetAction::Walk;
    if(!DActor->TileAligned()){
        DActor->Direction(DirectionOpposite(DActor->Position().TileOctant()));
    }
    DActor->PushCommand(AssetCommand);
    return true;
}

/**
* cancel the capability of the actor.
*
* @param[in] it does not have a parameter.
*
* @return return nothing.
*
*/
void CPlayerCapabilityAttack::CActivatedCapability::Cancel(){

    DActor->PopCommand();
}

/**
 *
 * @class CPlayerCapabilityRepair
 *
 * @ brief This class was written to give palayer capability to Repair \n
 *     <pre>
 *    The class contains two other clases which are CRegistrant and CActivatedCapability.
 *    They are resposible for determining the player who should get the cabability and activation of
 *    cabability. The class also keep tracks of precentge compelation of the capability
 *    the steps and cancelation of capability.
 *     </pre>
 * @author Seza
 *
 * @version 1.0
 *
 * @date 10/13/2017 21:04:00
 *
 * Contact: shabibi@ucdavis.edu
 *
 */
class CPlayerCapabilityRepair : public CPlayerCapability{
    protected:

      /**
       *
       *@class CRegistrant
       *
       * @brief the class was written to determine the player who should get the capability
       *
       * @author Seza
       *
       * @version 1.0
       *
       * @date 10/13/2017 23:17:00
       *
       * Contact: shabibi@ucdavis.edu
       */
        class CRegistrant{
            public:
                CRegistrant();
        };
        static CRegistrant DRegistrant;

        /**
         *
         *@class CActivatedCapability
         *
         * @brief the class was written to activate the player capability
         *     <pre>
         *      The class is resposible for showing the precentage completation until
         *      the player get the capabiltiy,following steps to get capability, and
         *      cancelation of capability.
         *     </pre>
         * @author Seza
         *
         * @version 1.0
         *
         * @date 10/13/2017 23:17:00
         *
         * Contact: shabibi@ucdavis.edu
         */
        class CActivatedCapability : public CActivatedPlayerCapability{
            protected:

            public:
                CActivatedCapability(std::shared_ptr< CPlayerAsset > actor, std::shared_ptr< CPlayerData > playerdata, std::shared_ptr< CPlayerAsset > target);
                virtual ~CActivatedCapability(){};

                int PercentComplete(int max);
                bool IncrementStep();
                void Cancel();
        };
        CPlayerCapabilityRepair();

    public:
        virtual ~CPlayerCapabilityRepair(){};

        bool CanInitiate(std::shared_ptr< CPlayerAsset > actor, std::shared_ptr< CPlayerData > playerdata);
        bool CanApply(std::shared_ptr< CPlayerAsset > actor, std::shared_ptr< CPlayerData > playerdata, std::shared_ptr< CPlayerAsset > target);
        bool ApplyCapability(std::shared_ptr< CPlayerAsset > actor, std::shared_ptr< CPlayerData > playerdata, std::shared_ptr< CPlayerAsset > target);
};

CPlayerCapabilityRepair::CRegistrant CPlayerCapabilityRepair::DRegistrant;

CPlayerCapabilityRepair::CRegistrant::CRegistrant(){
    CPlayerCapability::Register(std::shared_ptr< CPlayerCapabilityRepair >(new CPlayerCapabilityRepair()));
}

CPlayerCapabilityRepair::CPlayerCapabilityRepair() : CPlayerCapability(std::string("Repair"), ETargetType::Asset){

}

/**
* it will check if the actor can gain/ initiate capability.
*
* @param[in] actor shar pointer to the class of PlayerAsset.
* @param[in] playerdata  share pointer to the class of PlayerData
*
* @return boolian function if the acter can intiate capability or not
*
*/
bool CPlayerCapabilityRepair::CanInitiate(std::shared_ptr< CPlayerAsset > actor, std::shared_ptr< CPlayerData > playerdata){

    return (actor->Speed() > 0) && playerdata->Gold() && playerdata->Lumber();
}

/**
* it will check if capability can be apply to the actor. condition:
*     <pre>
*     actore's color must equal target color and target must not has speed.
*     Target HitPoints  must be smaller than target MaxHitPoints
*     CanInitiate function should return true
*    </pre>
* @param[in] actor share pointer to the class of PlayerAsset.
* @param[in] playerdata  share pointer to the class of PlayerData
* @param[in] playerdata  share pointer to the class of PlayerAsset
*
* @return boolian function if the acter can be applied for capability
*
*/
bool CPlayerCapabilityRepair::CanApply(std::shared_ptr< CPlayerAsset > actor, std::shared_ptr< CPlayerData > playerdata, std::shared_ptr< CPlayerAsset > target){
    if((actor->Color() != target->Color())||(target->Speed())){
        return false;
    }
    if(target->HitPoints() >= target->MaxHitPoints()){
        return false;
    }
    return CanInitiate(actor, playerdata);
}

/**
* set acter a new capability. using a struct and PushCommand function
*
* @param[in] actor share pointer to the class of PlayerAsset.
* @param[in] playerdata  share pointer to the class of PlayerData
* @param[in] playerdata  share pointer to the class of PlayerAsset
*
* @return boolian function if the actor got apability or not.
*
*/
bool CPlayerCapabilityRepair::ApplyCapability(std::shared_ptr< CPlayerAsset > actor, std::shared_ptr< CPlayerData > playerdata, std::shared_ptr< CPlayerAsset > target){
    if(actor->TilePosition() != target->TilePosition()){
        SAssetCommand NewCommand;

        NewCommand.DAction = EAssetAction::Capability;
        NewCommand.DCapability = AssetCapabilityType();
        NewCommand.DAssetTarget = target;
        NewCommand.DActivatedCapability = std::make_shared< CActivatedCapability >(actor, playerdata, target);
        actor->ClearCommand();
        actor->PushCommand(NewCommand);
        return true;
    }

    return false;
}

CPlayerCapabilityRepair::CActivatedCapability::CActivatedCapability(std::shared_ptr< CPlayerAsset > actor, std::shared_ptr< CPlayerData > playerdata, std::shared_ptr< CPlayerAsset > target) :
CActivatedPlayerCapability(actor, playerdata, target){

}

/**
* show the precentage completation of the capability.
*
* @param[in] max the number of max percent complete.
*
* @return number of perscentage compelete.
*
*/
int CPlayerCapabilityRepair::CActivatedCapability::PercentComplete(int max){
    return 0;
}

/**
* Set/initilize the next step.
*
* @brief it uses two struct to Acknowledgethe actor and make the command to gain
*         capability.
*
* @param[in] it does not have a parameter.
*
* @return bool function if actore gain the capability or not.
*
*/
bool CPlayerCapabilityRepair::CActivatedCapability::IncrementStep(){
    SAssetCommand AssetCommand;
    SGameEvent TempEvent;

    TempEvent.DType = EEventType::Acknowledge;
    TempEvent.DAsset = DActor;
    DPlayerData->AddGameEvent(TempEvent);

    AssetCommand.DAction = EAssetAction::Repair;
    AssetCommand.DAssetTarget = DTarget;
    DActor->ClearCommand();
    DActor->PushCommand(AssetCommand);

    AssetCommand.DAction = EAssetAction::Walk;
    if(!DActor->TileAligned()){
        DActor->Direction(DirectionOpposite(DActor->Position().TileOctant()));
    }
    DActor->PushCommand(AssetCommand);
    return true;
}

/**
* cancel the capability of the actor.
*
* @param[in] it does not have a parameter.
*
* @return return nothing.
*
*/
void CPlayerCapabilityRepair::CActivatedCapability::Cancel(){

    DActor->PopCommand();
}
